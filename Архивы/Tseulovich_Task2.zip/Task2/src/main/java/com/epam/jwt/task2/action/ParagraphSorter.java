package com.epam.jwt.task2.action;

import com.epam.jwt.task2.entity.Text;

public interface ParagraphSorter {
    void sort(Text text);
}
