package com.epam.jwt.task2.entity;

public interface PartOfText {
    String convertPartOfTextToString();
}
