package com.epam.jwt.task2.parser;

import com.epam.jwt.task2.entity.Text;

public interface StringParser {
    Text parseData(Object text);
}
