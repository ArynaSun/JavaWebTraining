package com.epam.jwt.task2.reader;

public interface DataReader {

    String readData();
}
