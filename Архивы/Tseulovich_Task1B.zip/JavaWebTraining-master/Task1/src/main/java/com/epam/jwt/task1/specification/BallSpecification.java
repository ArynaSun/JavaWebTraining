package com.epam.jwt.task1.specification;

import com.epam.jwt.task1.entity.Ball;

public interface BallSpecification {

    boolean isFit(Ball ball);
}
