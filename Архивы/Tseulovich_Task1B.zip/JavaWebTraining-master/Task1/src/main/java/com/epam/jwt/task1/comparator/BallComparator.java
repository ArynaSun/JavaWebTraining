package com.epam.jwt.task1.comparator;

import com.epam.jwt.task1.entity.Ball;

public interface BallComparator {

    int compare(Ball o1, Ball o2);
}
